# Coursera-Peer-graded-Assignment-Module-5-Coding-Assignment
This is Module 2 Coding Assignment for HTML, CSS, and Javascript for Web Developers course, one of Coursera full-stack web courses (Johns Hopkins University5
